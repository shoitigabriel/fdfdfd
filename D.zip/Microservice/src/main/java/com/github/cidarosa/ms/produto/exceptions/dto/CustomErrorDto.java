package com.github.cidarosa.ms.produto.exceptions.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.time.Instant;

@AllArgsConstructor
@NoArgsConstructor
@Getter
public class CustomErrorDto {

    private Instant timestamp;
    private Integer status;
    private String error;
    private String path;

}
