package com.github.cida.ms.pagamentos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsPagamentosApplicationTests {

	@Test
	void contextLoads() {
	}

}
