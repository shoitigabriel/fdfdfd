package com.github.cida.ms.pagamentos.controller;

//@SpringBootTest
//@AutoConfigureMockMvc
//@ActiveProfiles("test")
//@Transactional
public class PagamentoControllerIT {

//    @Autowired
//    private MockMvc mockMvc;
//
//    @Autowired
//    private ObjectMapper objectMapper;
//    private Pagamento pagamento;
//    private Long existingId;
//    private Long nonExistingId;
//
//    @BeforeEach
//    void setUp() {
//        existingId = 1L;
//        nonExistingId = Long.MAX_VALUE;
//    }
//
//    @Test
//    void findAllPagamentosShouldReturn200AndJsonArray() throws Exception {
//
//        mockMvc.perform(get("/pagamentos")
//                        .accept(MediaType.APPLICATION_JSON))
//                .andDo(print())
//                .andExpect(status().isOk())
//                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
//                .andExpect(jsonPath("$").isArray())
//                .andExpect(jsonPath("$[0].id").isNumber())
//                .andExpect(jsonPath("$[*].id").isArray())
//                .andExpect(jsonPath("$[1].valor").value(3599.0));
//    }
//
//    @Test
//    void findPagamentoByIdShouldReturn200WhenIdExists() throws Exception {
//
//        mockMvc.perform(get("/pagamentos/{id}", existingId)
//                        .accept(MediaType.APPLICATION_JSON))
//                .andDo(print())
//                .andExpect(status().isOk())
//                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
//                .andExpect(jsonPath("$.id").value(1))
//                .andExpect(jsonPath("$.nome").value("Jon Snow"))
//                .andExpect(jsonPath("$.status").value("CRIADO"));
//    }
//
//    @Test
//    void findPagamentoByIdShouldReturn404WhenIdDoesNotExist() throws Exception {
//
//        mockMvc.perform(get("/pagamentos/{id}", nonExistingId)
//                        .accept(MediaType.APPLICATION_JSON)
//                )
//                .andDo(print())
//                .andExpect(status().isNotFound());
//    }
//
//    @Test
//    void createPagamentoShouldReturn201WhenValid() throws Exception {
//
//        PagamentoResponseDTO pagamentoDTO = new PagamentoResponseDTO(Factory.createPagamentoSemId());
//        String jsonRequestBody = objectMapper.writeValueAsString(pagamentoDTO);
//
//        mockMvc.perform(post("/pagamentos")
//                        .contentType(MediaType.APPLICATION_JSON)
//                        .accept(MediaType.APPLICATION_JSON)
//                        .content(jsonRequestBody))
//                .andDo(print())
//                .andExpect(status().isCreated())
//                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
//                .andExpect(jsonPath("$.id").isNumber())
//                .andExpect(jsonPath("$.status").value("CRIADO"));
//    }
//
//    @Test
//    void createPagamentoShouldReturn422WhenInvalid() throws Exception {
//
//        Pagamento pagamentoInvalido = Factory.createPagamentoSemId();
//        pagamentoInvalido.setValor(BigDecimal.valueOf(0));
//        pagamentoInvalido.setNome(null);
//        PagamentoResponseDTO requestDTO = new PagamentoResponseDTO(pagamentoInvalido);
//
//        String jsonRequestBody = objectMapper.writeValueAsString(requestDTO);
//
//        mockMvc.perform(post("/pagamentos")
//                        .contentType(MediaType.APPLICATION_JSON)
//                        .accept(MediaType.APPLICATION_JSON)
//                        .content(jsonRequestBody))
//                .andDo(print())
//                .andExpect(status().isUnprocessableEntity())
//                .andExpect(jsonPath("$.error").value("Dados inválidos"))
//                .andExpect(jsonPath("$.errors").isArray());
//    }
//
//    @Test
//    void updatePagamentoShouldReturn200WhenIdExists() throws Exception {
//
//        pagamento = Factory.createPagamento();
//        PagamentoResponseDTO requestDTO = new PagamentoResponseDTO(pagamento);
//        String jsonRequestBody = objectMapper.writeValueAsString(requestDTO);
//
//        mockMvc.perform(put("/pagamentos/{id}", existingId)
//                        .contentType(MediaType.APPLICATION_JSON)
//                        .accept(MediaType.APPLICATION_JSON)
//                        .content(jsonRequestBody))
//                .andDo(print())
//                .andExpect(status().isOk())
//                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
//                .andExpect(jsonPath("$.id").value(existingId))
//                .andExpect(jsonPath("$.nome").value(pagamento.getNome()));
//    }
//
//    @Test
//    void updatePagamentoShouldReturn422WhenInvalid() throws Exception {
//
//        pagamento = Factory.createPagamento();
//        pagamento.setNome(null);
//        pagamento.setValor(BigDecimal.valueOf(-32.05));
//        pagamento.setPedidoId(null);
//
//        PagamentoResponseDTO requestDTO = new PagamentoResponseDTO(pagamento);
//        String jsonRequestBody = objectMapper.writeValueAsString(requestDTO);
//
//        mockMvc.perform(put("/pagamentos/{id}", existingId)
//                        .contentType(MediaType.APPLICATION_JSON)
//                        .accept(MediaType.APPLICATION_JSON)
//                        .content(jsonRequestBody))
//                .andDo(print())
//                .andExpect(status().isUnprocessableEntity())
//                .andExpect(jsonPath("$.error").value("Dados inválidos"))
//                .andExpect(jsonPath("$.errors").isArray());
//    }
//
//    @Test
//    void updatePagamentoShouldReturn404WhenIdDoesNotExist() throws Exception {
//
//        pagamento = Factory.createPagamento();
//        PagamentoResponseDTO requestDTO = new PagamentoResponseDTO(pagamento);
//        String jsonRequestBody = objectMapper.writeValueAsString(requestDTO);
//
//        mockMvc.perform(put("/pagamentos/{id}", nonExistingId)
//                        .contentType(MediaType.APPLICATION_JSON)
//                        .accept(MediaType.APPLICATION_JSON)
//                        .content(jsonRequestBody))
//                .andDo(print())
//                .andExpect(status().isNotFound());
//    }
//
//    @Test
//    void deletePagamentoShouldReturn204WhenIdExists() throws Exception{
//
//        mockMvc.perform(delete("/pagamentos/{id}", existingId))
//                .andDo(print())
//                .andExpect(status().isNoContent());
//    }
//
//    @Test
//    void deletePagamentoShouldReturn404WhenIdDoesExist() throws Exception{
//
//        mockMvc.perform(delete("/pagamentos/{id}", nonExistingId))
//                .andDo(print())
//                .andExpect(status().isNotFound());
//    }

}
